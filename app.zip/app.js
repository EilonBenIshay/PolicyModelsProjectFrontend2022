//'use strict'
const template = document.createElement('template');
template.innerHTML = `
 <style>

 .btn {
    font-size: 15px;
    font-weight: 100;
    letter-spacing: 1px;
    padding: 5px 10px 5px;
    outline: 0;
    border: 1px solid black;
    cursor: pointer;
    position: relative;
    background-color: rgba(0, 0, 0, 0);
    user-select: none;
    -webkit-user-select: none;
    touch-action: manipulation;
  }
  
  .btn:after {
    content: "";
    background-color: #cfebfd;
    width: 100%;
    z-index: -1;
    position: absolute;
    height: 100%;
    top: 7px;
    left: 7px;
    transition: 0.2s;
  }
  
  .btn:hover:after {
    top: 0px;
    left: 0px;
  }
  
  @media (min-width: 768px) {
    .btn {
      padding: 10px 15px 10px;
    }
  }


    .web-component {
        text-align:center
    }
     h3 {
        color: #cfebfd;
    }
    .transcript {
        display: none
    }
 </style>
 <div class="web-component"> 
    <div>
        <h3></h3>
        <h4></h4>
        <p id="demo"> </p>
    </div>
    <div class="buttons">
    </div>
    <div><button id="transcript-toggle">show transcript</button></div>
    <div class="transcript"></div>
    <label for="QReturns">return to question: </label>
    <select name = "QReturns" id = "QReturns">
    <option value=0>choose a question</option>
    </select>
 </div>
`; 

class PolicyModelsDefault extends HTMLElement{
    constructor(){
        super();
        
        this.showInfo = true;
        this.transcriptFlag = false;
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.appendChild(template.content.cloneNode(true));
        this.shadowRoot.querySelector('h3').innerText = this.getAttribute('name');
        this.question = [0,"Welcome to the PolicyModels test site!", ["Start interview"]]
        this.shadowRoot.querySelector('h4').innerText = this.question[1];
        this.shadowRoot.querySelector('.buttons').innerHTML = "<button class = \"btnStart\" id =\"a0\">" + this.question[2][0] + "</button>\n";
        this.buttons = ['#a0'];
        this.shadowRoot.querySelector('#a0').addEventListener('click', () => this.QuestionSetUp(""));
        
        //NEW
        this.shadowRoot.querySelector('.buttons').innerHTML = "<button class = \"btnTry\"> click </button>\n";
        this.shadowRoot.querySelector('.btnTry').addEventListener('click', () => this.httpGet());

        // answers arre represented in a map
        this.answers = new Map();
              
        ///to be removed later
        this.Qnum = 0;
        this.QuestionBank = [[1, "Are you a woman?", ["Yes", "No"]],
                            [2, "How old are you?",["1-14","15-18","19-65","66+"]],
                            [3, "How did your employment end?", ["Resignation", "Lawful Termination", "Unlawful Termination", "Death"]],
                            [4, "What is your favorite chip?", ["Pringles", "Lays", "Walkers", "Tapuchips", "Other"]],
                            [5, "How has your day been?", ["Best day of my life", "Great", "Ok", "Bad", "Straight up agony"]],
                            [6, "What is your favorite animal", ["Dog", "Cat", "Mouse", "Frog", "Hedgehog", "Bee", "Wolf", "Other"]],
                            [7, "Who is the best?", ["Shady", "Shelly", "Eilon", "Tbh none of them"]],
                            [8, "Are you an israeli citizan", ["Yes","No"]],
                            [9, "Who is the best friend?", ["Ross", "Chandler", "Monica", "Rachel", "Pheobe", "Joey"]],
                            [10, "HIMYM or Seinfeld?", ["HIMYM", "Seinfeld", "F.r.i.e.n.d.s", "other"]],
                            [-1, "These are your results:"]];
        ///to be removed later

    }

    connectedCallback(){
        this.shadowRoot.querySelector('#QReturns').addEventListener('change', (event) => this.ReturnToQuestion(event.target.value));
        this.shadowRoot.querySelector('#transcript-toggle').addEventListener('click', () => this.toggleTranscript());
    }

    disconnectedCallback(){
        this.shadowRoot.querySelector('#QReturns').removeEventListener();
    }

    /**
     * Loads up the next question in the interview.
     */
    FetchQuestion(answer){
        if (answer != undefined)
            this.answers.set(this.Qnum, answer);
        this.question = this.QuestionBank[this.Qnum];
        this.Qnum = this.Qnum + 1;
    }

    /**
     * set up a return to question button
     */
    ReturnSetUp(){
        if (this.Qnum < 2 || this.Qnum > 9)
            return;
        let returnButtonSTR = "<option value=0>choose a question</option>\n";
        for(let i = 1; i < this.Qnum; i++)
            returnButtonSTR += ("<option value = " + i.toString() +">question " + i.toString() + "</option>\n");
        this.shadowRoot.querySelector("#QReturns").innerHTML = returnButtonSTR;
    }

    /**
     * sets up the transcript
     */
    setTranscript(){
        let transcript = this.shadowRoot.querySelector('.transcript');
        transcript.innerHTML = "";
        for(let i = 1; i < this.Qnum; i++)
            transcript.innerHTML += ("<div>question "+ i.toString() +": " + this.QuestionBank[i-1][1]+"&emsp;&emsp;&emsp;your answer: " +
                this.answers.get(i) + "</div>")
    }

    /**
     * Sets up the current Question.
     */
    QuestionSetUp(answer){
        this.FetchQuestion(answer);
        this.shadowRoot.querySelector('h4').innerText = this.question[1]; 
        this.setTranscript(); 
        if(this.question[0] == -1)
            this.Conclude();
        else
            this.ButtonSetUp()
    }


    /**
     * sets up the buttons for the current question.
     */
    ButtonSetUp(){
        let btnIDs = [];
        let btnSTR = ""; 
    
        for (let i = 0; i< this.question[2].length; i++){
            btnSTR += "<button class = \"btn\" id =\"a" + i.toString() + "\">" + this.question[2][i] + "</button>\n";
            btnIDs[i] = '#a' + i.toString();
        } 
        this.shadowRoot.querySelector('.buttons').innerHTML = btnSTR;
        for (let j = 0; j< this.question[2].length; j++){
            this.shadowRoot.querySelector(btnIDs[j]).addEventListener('click', () => this.QuestionSetUp(this.question[2][j]));
        }

        this.ReturnSetUp();  
    }

    /**
     * Concludes the interview
     */
    Conclude(){
        let answersStr = "";
        this.answers.forEach((value, key) => answersStr += (value + ","));
        answersStr = answersStr.substring(1, answersStr.length-1);
        answersStr ="[" + answersStr + "]";
        this.shadowRoot.querySelector('.buttons').innerHTML = "<h5>hi</h5>";
        this.shadowRoot.querySelector('.buttons').innerText = answersStr;
        this.shadowRoot.querySelector('.QReturns').innerHTML = "";
    }

    /**
     * returns to a specific question
     */
    ReturnToQuestion(questionNum){
        if(questionNum > 9 || questionNum < 1){
            return;
        }
        this.Qnum = questionNum -1;
        this.answers.forEach((value, key) => {if(key >= questionNum) this.answers.delete(key)});
        this.QuestionSetUp();

    }

    toggleTranscript(){
        let info = this.shadowRoot.querySelector('.transcript');
        let btn = this.shadowRoot.querySelector('#transcript-toggle');
        this.transcriptFlag = !this.transcriptFlag;
        if(this.transcriptFlag){
            info.style.display = 'block';
            btn.innerText = "hide tanscript";
        }
        else{
            info.style.display = 'none';
            btn.innerText = "show tanscript";
        }
    }
    httpGet()
    {
        // prompt("before1");
        // var XMLHttpRequest = require('xhr2');
        // var xmlHttp = new XMLHttpRequest();
        // const Url = 'http://localhost:9000/api/1/models/testInterviewConnection';
        // xmlHttp.open( "GET", Url, false ); // false for synchronous request
        // xmlHttp.send( null );
        // return xmlHttp.responseText;
        var theUrl = 'http://localhost:9000/api/1/models/testInterviewConnection';
        var xmlHttp = new XMLHttpRequest();
        xmlHttp.onreadystatechange = function() { 
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200)
            callback(xmlHttp.responseText);
        }
        xmlHttp.open("GET", theUrl, true); // true for asynchronous 
        xmlHttp.send(null);
        prompt("xmlHttp.responseText is"+xmlHttp.responseText);
    }


}

window.customElements.define('web-component',PolicyModelsDefault); //the name of the tag and the name of the class we want to be connected